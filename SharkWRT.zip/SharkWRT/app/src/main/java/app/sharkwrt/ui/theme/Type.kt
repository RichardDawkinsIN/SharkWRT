package app.sharkwrt.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.sharkwrt.R

val AbyssSans = FontFamily(
    Font(R.font.rajdhani_400regular, FontWeight.Normal), Font(R.font.rajdhani_500medium, FontWeight.Medium),
    Font(R.font.rajdhani_600semibold, FontWeight.SemiBold), Font(R.font.rajdhani_600semibold, FontWeight(650)),
    Font(R.font.rajdhani_700bold, FontWeight.Bold),
)
val AbyssDisplay = FontFamily(Font(R.font.orbitron_600semibold, FontWeight.SemiBold), Font(R.font.orbitron_700bold, FontWeight.Bold), Font(R.font.orbitron_700bold, FontWeight.ExtraBold))
val AuroraSans = FontFamily(
    Font(R.font.plusjakartasans_400regular, FontWeight.Normal), Font(R.font.plusjakartasans_500medium, FontWeight.Medium),
    Font(R.font.plusjakartasans_600semibold, FontWeight.SemiBold), Font(R.font.plusjakartasans_600semibold, FontWeight(650)),
    Font(R.font.plusjakartasans_700bold, FontWeight.Bold),
)
val AuroraDisplay = FontFamily(Font(R.font.plusjakartasans_700bold, FontWeight.SemiBold), Font(R.font.plusjakartasans_800extrabold, FontWeight.Bold), Font(R.font.plusjakartasans_800extrabold, FontWeight.ExtraBold))
val DeckMono = FontFamily(
    Font(R.font.jetbrainsmono_400regular, FontWeight.Normal), Font(R.font.jetbrainsmono_500medium, FontWeight.Medium),
    Font(R.font.jetbrainsmono_500medium, FontWeight.SemiBold), Font(R.font.jetbrainsmono_500medium, FontWeight(650)),
    Font(R.font.jetbrainsmono_700bold, FontWeight.Bold), Font(R.font.jetbrainsmono_700bold, FontWeight.ExtraBold),
)
val GroteskSans = FontFamily(
    Font(R.font.spacegrotesk_400regular, FontWeight.Normal), Font(R.font.spacegrotesk_500medium, FontWeight.Medium),
    Font(R.font.spacegrotesk_600semibold, FontWeight.SemiBold), Font(R.font.spacegrotesk_600semibold, FontWeight(650)),
    Font(R.font.spacegrotesk_700bold, FontWeight.Bold),
)
val SoraDisplay = FontFamily(Font(R.font.sora_600semibold, FontWeight.SemiBold), Font(R.font.sora_700bold, FontWeight.Bold), Font(R.font.sora_800extrabold, FontWeight.ExtraBold))
val ArchivoDisplay = FontFamily(Font(R.font.archivoblack_400regular, FontWeight.Normal), Font(R.font.archivoblack_400regular, FontWeight.SemiBold), Font(R.font.archivoblack_400regular, FontWeight.Bold), Font(R.font.archivoblack_400regular, FontWeight.ExtraBold))

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun vf(res: Int, w: FontWeight) = Font(res, weight = w, variationSettings = FontVariation.Settings(FontVariation.weight(w.weight)))
private fun vfam(res: Int) = FontFamily(
    vf(res, FontWeight.Normal), vf(res, FontWeight.Medium), vf(res, FontWeight.SemiBold), vf(res, FontWeight(650)),
    vf(res, FontWeight.Bold), vf(res, FontWeight.ExtraBold),
)
val DmSans = vfam(R.font.dmsans_var)
val OutfitSans = vfam(R.font.outfit_var)
val InterTight = vfam(R.font.intertight_var)
val PlexMono = FontFamily(
    Font(R.font.plexmono_400regular, FontWeight.Normal), Font(R.font.plexmono_500medium, FontWeight.Medium),
    Font(R.font.plexmono_600semibold, FontWeight.SemiBold), Font(R.font.plexmono_600semibold, FontWeight(650)),
    Font(R.font.plexmono_600semibold, FontWeight.Bold), Font(R.font.plexmono_600semibold, FontWeight.ExtraBold),
)
val PressStart = FontFamily(
    Font(R.font.pressstart2p_400regular, FontWeight.Normal), Font(R.font.pressstart2p_400regular, FontWeight.Medium),
    Font(R.font.pressstart2p_400regular, FontWeight.SemiBold), Font(R.font.pressstart2p_400regular, FontWeight.Bold),
    Font(R.font.pressstart2p_400regular, FontWeight.ExtraBold),
)
val Vt323 = FontFamily(
    Font(R.font.vt323_400regular, FontWeight.Normal), Font(R.font.vt323_400regular, FontWeight.Medium),
    Font(R.font.vt323_400regular, FontWeight.SemiBold), Font(R.font.vt323_400regular, FontWeight(650)),
    Font(R.font.vt323_400regular, FontWeight.Bold), Font(R.font.vt323_400regular, FontWeight.ExtraBold),
)

/** Kept for the Material typography below; the app's own text asks [Wrt] for the style's family. */
val SansFamily = GroteskSans
val DisplayFamily = SoraDisplay

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun mono(weight: FontWeight) = Font(
    R.font.red_hat_mono_var,
    weight = weight,
    variationSettings = FontVariation.Settings(FontVariation.weight(weight.weight)),
)

val MonoFamily = FontFamily(
    mono(FontWeight.Normal),
    mono(FontWeight.Medium),
    mono(FontWeight.SemiBold),
    mono(FontWeight.Bold),
)

val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = SansFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = SansFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 20.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = SansFamily,
        fontWeight = FontWeight(650),
        fontSize = 24.sp,
        letterSpacing = (-0.24).sp,
    ),
)
