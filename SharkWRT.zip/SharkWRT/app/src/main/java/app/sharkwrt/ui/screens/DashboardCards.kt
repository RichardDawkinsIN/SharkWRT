package app.sharkwrt.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import app.sharkwrt.ui.Text
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.sharkwrt.data.RouterOps
import app.sharkwrt.data.UsageState
import app.sharkwrt.ops.NetUsage
import app.sharkwrt.ui.GhostButton
import app.sharkwrt.ui.PrimaryButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import app.sharkwrt.data.Telemetry
import app.sharkwrt.ui.FlexSpacer
import app.sharkwrt.ui.SectionLabel
import app.sharkwrt.ui.Sparkline
import app.sharkwrt.ui.StatusDot
import app.sharkwrt.ui.glassBg
import app.sharkwrt.ui.glassBorder
import app.sharkwrt.ui.mono
import app.sharkwrt.ui.sans
import app.sharkwrt.ui.theme.Wrt

/** A speed in Mbps as a number and its unit, so 0.4 reads "400 kbps" and 1250 reads "1.25 Gbps". */
internal fun speedParts(mbps: Float): Pair<String, String> = when {
    mbps >= 1000f -> String.format("%.2f", mbps / 1000f) to "Gbps"
    mbps >= 100f -> String.format("%.0f", mbps) to "Mbps"
    mbps >= 10f -> String.format("%.1f", mbps) to "Mbps"
    mbps >= 1f -> String.format("%.2f", mbps) to "Mbps"
    mbps > 0f -> String.format("%.0f", mbps * 1000f) to "kbps"
    else -> "0" to "Mbps"
}

/**
 * The current download and upload speed, big, each with its own last-minute line and the peak
 * in that minute. [down] and [up] are the upstream's Mbps, newest last — the same series the
 * upstream card charts.
 */
@Composable
fun LiveSpeedCard(down: List<Float>, up: List<Float>, live: Boolean, stale: Boolean) {
    val now = down.lastOrNull() ?: 0f
    val upNow = up.lastOrNull() ?: 0f
    val peak = maxOf(down.maxOrNull() ?: 0f, 50f)
    val frac by androidx.compose.animation.core.animateFloatAsState((now / (peak * 1.15f)).coerceIn(0f, 1f), androidx.compose.animation.core.tween(700), label = "ring")
    val spin by androidx.compose.animation.core.rememberInfiniteTransition(label = "spin").animateFloat(
        0f, 360f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(30000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "spinAngle",
    )
    if (!Wrt.style.ring) {
        Column(
            Modifier.fillMaxWidth()
                .glassBorder(RoundedCornerShape(Wrt.r(28f)))
                .glassBg(RoundedCornerShape(Wrt.r(28f)))
                .padding(14.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("LIVE SPEED", size = 9.5f)
                FlexSpacer()
                StatusDot(if (stale) Wrt.Amber else Wrt.Blue, 5.dp, pulse = live && !stale)
                Text(
                    if (!live) "DEMO" else if (stale) "WAITING" else "LIVE",
                    style = mono(9f, 600, if (stale && live) Wrt.Amber else Wrt.Blue, letterSpacing = 0.14.em),
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                SpeedTile(Modifier.weight(1f), "DOWNLOAD", down, Wrt.Blue)
                SpeedTile(Modifier.weight(1f), "UPLOAD", up, Wrt.Accent)
            }
        }
        return
    }
    val track = Wrt.ProgressTrack
    val ringLine = Wrt.TextPrimary.copy(alpha = 0.26f)
    val cyan = Wrt.Blue
    val accent = Wrt.Accent
    Column(
        Modifier
            .fillMaxWidth()
            .glassBorder(RoundedCornerShape(Wrt.r(32f)))
            .glassBg(RoundedCornerShape(Wrt.r(32f)))
            .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionLabel("LIVE SPEED", size = 9.5f)
            FlexSpacer()
            StatusDot(if (stale) Wrt.Amber else Wrt.Blue, 5.dp, pulse = live && !stale)
            Text(
                if (!live) "DEMO" else if (stale) "WAITING" else "LIVE",
                style = mono(9f, 600, if (stale && live) Wrt.Amber else Wrt.Blue, letterSpacing = 0.14.em),
            )
        }
        Box(Modifier.padding(top = 10.dp).size(244.dp), contentAlignment = Alignment.Center) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val stroke = 16.dp.toPx()
                val inset = stroke / 2f
                val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
                val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)
                drawArc(track, 135f, 270f, false, topLeft, arcSize, style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round))
                if (frac > 0.003f) {
                    drawArc(
                        Brush.linearGradient(listOf(cyan, Wrt.Accent2, accent), start = androidx.compose.ui.geometry.Offset(0f, size.height), end = androidx.compose.ui.geometry.Offset(size.width, 0f)),
                        135f, 270f * frac, false, topLeft, arcSize,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round),
                    )
                }
                val r = size.minDimension / 2f - stroke - 12.dp.toPx()
                rotate(spin) {
                    drawCircle(
                        ringLine, r, center,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 7.dp.toPx()))),
                    )
                    drawCircle(cyan, 4.5.dp.toPx(), androidx.compose.ui.geometry.Offset(center.x, center.y - r))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val (value, unit) = speedParts(now)
                Text("DOWNLOAD", style = mono(9.5f, 600, Wrt.TextDim, letterSpacing = 0.16.em))
                Text(value, style = androidx.compose.ui.text.TextStyle(fontFamily = Wrt.displayFamily, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold, fontSize = (50 * Wrt.style.displayScale).sp, color = Wrt.TextPrimary, letterSpacing = (-2).sp), maxLines = 1, softWrap = false)
                Text(unit, style = sans(13f, 650, Wrt.Blue))
                val (uv, uu) = speedParts(upNow)
                Row(
                    Modifier.padding(top = 10.dp).background(Wrt.TextPrimary.copy(alpha = 0.08f), Wrt.pill()).padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text("↑", style = sans(13f, 700, Wrt.Accent))
                    Text("$uv $uu", style = sans(13.5f, 650, Wrt.Accent))
                }
            }
        }
        val (pv, pu) = speedParts(down.maxOrNull() ?: 0f)
        Text("peak $pv $pu this minute", style = mono(9.5f, 500, Wrt.TextDim), modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun SpeedTile(modifier: Modifier, label: String, series: List<Float>, color: Color) {
    val now = series.lastOrNull() ?: 0f
    val peak = series.maxOrNull() ?: 0f
    val (value, unit) = speedParts(now)
    Column(modifier) {
        Text(label, style = mono(9f, 600, color, letterSpacing = 0.12.em))
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(value, style = mono(24f, 600), maxLines = 1, softWrap = false)
            Text(unit, style = mono(10.5f, 500, Wrt.TextDim), modifier = Modifier.padding(bottom = 4.dp), maxLines = 1)
        }
        Sparkline(series, color, Modifier.fillMaxWidth().height(26.dp).padding(top = 6.dp), maxY = 0f)
        val (pv, pu) = speedParts(peak)
        Text("peak $pv $pu", style = mono(9.5f, 500, Wrt.TextDim), modifier = Modifier.padding(top = 4.dp), maxLines = 1)
    }
}

/**
 * Data usage. With the NetUsage tracker on the router this is the router's own history —
 * today, this month or billing cycle against the cap, and a bar per day or month — and it
 * survives reboots because vnstat's database sits on flash. Without it the card falls back to
 * the interface counters, which restart from zero at every boot, and offers to set the tracker up.
 */
@Composable
fun DataUsageCard(live: Telemetry?, upstreamName: String?, history: UsageState, onSetup: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .glassBorder(RoundedCornerShape(Wrt.r(28f)))
            .glassBg(RoundedCornerShape(Wrt.r(28f)))
            .padding(start = 13.dp, end = 13.dp, top = 12.dp, bottom = 12.dp)
    ) {
        when (history) {
            is UsageState.Ready -> UsageHistory(history.summary, live)
            else -> UsageSinceBoot(live, upstreamName, history, onSetup)
        }
    }
}

@Composable
internal fun UsageHistory(u: NetUsage.Summary, live: Telemetry?) {
    var monthly by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionLabel("DATA USAGE · ${u.iface.uppercase()}", size = 9.5f)
        FlexSpacer()
        ViewToggle("DAILY", !monthly) { monthly = false }
        ViewToggle("MONTHLY", monthly) { monthly = true }
    }
    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        UsageTile(Modifier.weight(1f), "TODAY", u.todayRx, u.todayTx)
        UsageTile(Modifier.weight(1f), if (u.isCalendarMonth) "THIS MONTH" else "THIS CYCLE", u.cycleRx, u.cycleTx)
    }
    if (u.capGb > 0) {
        val pct = u.cycleBytes.toFloat() / u.capBytes.toFloat() * 100f
        val barColor = when {
            pct >= 95f -> Wrt.Red
            pct >= 80f -> Wrt.Amber
            else -> Wrt.Accent
        }
        Box(Modifier.fillMaxWidth().padding(top = 12.dp).height(5.dp).background(Wrt.ProgressTrack, RoundedCornerShape(Wrt.r(3f)))) {
            Box(
                Modifier
                    .fillMaxWidth((pct / 100f).coerceIn(0.01f, 1f))
                    .height(5.dp)
                    .background(barColor, RoundedCornerShape(Wrt.r(3f)))
            )
        }
        Row(Modifier.padding(top = 6.dp)) {
            Text(
                "${Telemetry.bytesLabel(u.cycleBytes)} of ${u.capGb} GB · ${String.format("%.0f", pct)}%",
                style = mono(10f, 500, Wrt.TextSecondary),
            )
            FlexSpacer()
            Text("on pace for ${Telemetry.bytesLabel(u.projectedBytes)}", style = mono(10f, 500, Wrt.TextDim))
        }
    }
    // One bar per day (last 14) or per month (last 6): down and up stacked.
    val bars: List<Triple<String, Long, Long>> =
        if (monthly) u.recentMonths.map { Triple(it.label.takeLast(2), it.rx, it.tx) }
        else u.recentDays.map { Triple(it.label.takeLast(2), it.rx, it.tx) }
    if (bars.isEmpty()) {
        Text(
            "No ${if (monthly) "monthly" else "daily"} data yet — vnstat saves every 15 minutes.",
            style = sans(11f, 400, Wrt.TextDim),
            modifier = Modifier.padding(top = 12.dp),
        )
    } else {
        val peak = bars.maxOf { it.second + it.third }.coerceAtLeast(1L).toFloat()
        Row(
            Modifier.fillMaxWidth().padding(top = 14.dp).height(54.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            bars.forEach { (_, rx, tx) ->
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Bottom) {
                    val full = ((rx + tx) / peak * 54f).coerceAtLeast(1f)
                    val txH = (tx / (rx + tx).coerceAtLeast(1L).toFloat() * full)
                    Box(Modifier.fillMaxWidth().height(txH.dp).background(Wrt.Blue, RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)))
                    Box(Modifier.fillMaxWidth().height((full - txH).dp).background(Wrt.Accent))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            bars.forEach { (label, _, _) ->
                Text(label, style = mono(8.5f, 500, Wrt.TextDim), modifier = Modifier.weight(1f), maxLines = 1, softWrap = false)
            }
        }
    }
    Row(Modifier.padding(top = 10.dp)) {
        Text(
            "Saved on the router · survives reboots" + (u.since?.let { " · since $it" } ?: ""),
            style = mono(9.5f, 500, Wrt.TextDim),
            maxLines = 1,
        )
        FlexSpacer()
        live?.let { Text("boot ↓ ${Telemetry.bytesLabel(it.totalRxBytes)} ↑ ${Telemetry.bytesLabel(it.totalTxBytes)}", style = mono(9.5f, 500, Wrt.TextDim), maxLines = 1) }
    }
}

@Composable
private fun ViewToggle(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        style = mono(9f, 600, if (selected) Wrt.Accent else Wrt.TextDim, letterSpacing = 0.12.em),
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
private fun UsageTile(modifier: Modifier, label: String, rx: Long, tx: Long) {
    Column(modifier) {
        Text(label, style = mono(9f, 600, Wrt.TextDim, letterSpacing = 0.12.em))
        Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
            Text("↓ ${Telemetry.bytesLabel(rx)}", style = mono(14f, 600, Wrt.Accent), maxLines = 1, softWrap = false)
        }
        Text("↑ ${Telemetry.bytesLabel(tx)}", style = mono(12f, 600, Wrt.Blue), modifier = Modifier.padding(top = 2.dp), maxLines = 1, softWrap = false)
    }
}

/** No tracker (or still loading): the counters since the router booted, plus the way to set it up. */
@Composable
private fun UsageSinceBoot(live: Telemetry?, upstreamName: String?, history: UsageState, onSetup: () -> Unit) {
    val rx = live?.totalRxBytes ?: 0L
    val tx = live?.totalTxBytes ?: 0L
    val known = live != null && !live.stale && (rx > 0L || tx > 0L)
    Row(verticalAlignment = Alignment.CenterVertically) {
        SectionLabel("DATA USAGE" + (upstreamName?.let { " · ${it.uppercase()}" } ?: ""), size = 9.5f)
        FlexSpacer()
        Text("SINCE BOOT", style = mono(9f, 600, Wrt.TextDim, letterSpacing = 0.14.em))
    }
    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text("↓ DOWNLOADED", style = mono(9f, 600, Wrt.Accent, letterSpacing = 0.12.em))
            Text(if (known) Telemetry.bytesLabel(rx) else "—", style = mono(22f, 600), modifier = Modifier.padding(top = 4.dp), maxLines = 1, softWrap = false)
        }
        Column(Modifier.weight(1f)) {
            Text("↑ UPLOADED", style = mono(9f, 600, Wrt.Blue, letterSpacing = 0.12.em))
            Text(if (known) Telemetry.bytesLabel(tx) else "—", style = mono(22f, 600), modifier = Modifier.padding(top = 4.dp), maxLines = 1, softWrap = false)
        }
    }
    if (known) {
        val total = (rx + tx).coerceAtLeast(1L).toFloat()
        val downShare = (rx / total).coerceIn(0.02f, 0.98f)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp).height(5.dp)) {
            Box(Modifier.weight(downShare).fillMaxHeight().background(Wrt.Accent, RoundedCornerShape(Wrt.r(3f))))
            Box(Modifier.weight(1f - downShare).fillMaxHeight().padding(start = 2.dp).background(Wrt.Blue, RoundedCornerShape(Wrt.r(3f))))
        }
    }
    when (history) {
        UsageState.Loading -> Unit
        UsageState.NotInstalled, UsageState.NoVnstat -> {
            Text(
                "These counters start from zero whenever the router reboots. Set up usage history to " +
                    "keep daily and monthly totals on the router itself.",
                style = sans(11f, 400, Wrt.TextDim, lineHeight = 16.sp),
                modifier = Modifier.padding(top = 10.dp),
            )
            GhostButton(
                "Set up usage history",
                modifier = Modifier.padding(top = 10.dp),
                border = Wrt.Accent,
                textColor = Wrt.Accent,
                onClick = onSetup,
            )
        }
        is UsageState.Failed ->
            Text(history.message, style = sans(10.5f, 400, Wrt.Amber), modifier = Modifier.padding(top = 10.dp))
        is UsageState.Ready -> Unit
    }
}

/**
 * Offers to put the NetUsage tracker on the router. It says what the installer does first,
 * because it installs packages, changes where vnstat keeps its database, and restarts services.
 */
@Composable
fun UsageSetupDialog(ops: RouterOps, onDismiss: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var working by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    Dialog(onDismissRequest = { if (!working) onDismiss() }) {
        Column(
            Modifier
                .fillMaxWidth()
                .glassBorder(RoundedCornerShape(Wrt.r(16f)))
                .background(Wrt.BgDialog, RoundedCornerShape(Wrt.r(16f)))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Text("Keep usage across reboots", style = sans(15f, 650))
            Text(
                "This sends the NetUsage installer to the router's shell. It will:\n" +
                    "• install vnstat, and nlbwmon for per-device figures, from the package feeds\n" +
                    "• keep vnstat's database on flash (/etc/vnstat), saved every 15 minutes and at shutdown\n" +
                    "• install Ookla's speed-test client in /usr/bin when the CPU is supported\n" +
                    "• add a Status › Data Usage page to LuCI and a few helper scripts\n" +
                    "• restart rpcd, cron and the web server\n\n" +
                    "The router needs internet. It can take a few minutes.",
                style = sans(12f, 400, Wrt.TextSecondary, lineHeight = 18.sp),
                modifier = Modifier.padding(top = 8.dp),
            )
            finished?.let { (ok, tail) ->
                Text(
                    if (ok) "Done. Totals start counting now." else "It did not finish:",
                    style = sans(12f, 650, if (ok) Wrt.Green else Wrt.Red),
                    modifier = Modifier.padding(top = 12.dp),
                )
                Text(tail, style = mono(10f, 500, Wrt.TextDim, lineHeight = 15.sp), modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.height(16.dp))
            PrimaryButton(
                when {
                    working -> "Installing…"
                    finished?.first == true -> "Close"
                    finished != null -> "Try again"
                    else -> "Install"
                },
                onClick = {
                    if (working) return@PrimaryButton
                    if (finished?.first == true) { onDone(); return@PrimaryButton }
                    working = true
                    scope.launch {
                        val script = withContext(Dispatchers.IO) {
                            runCatching { context.assets.open(NetUsage.SCRIPT_ASSET).use { it.readBytes() } }.getOrNull()
                        }
                        finished = if (script == null) false to "The installer is missing from this build."
                        else ops.installUsageTracker(script)
                        working = false
                    }
                },
            )
            Spacer(Modifier.height(6.dp))
            GhostButton(if (finished?.first == true) "Close" else "Cancel", onClick = { if (!working) onDismiss() })
        }
    }
}
