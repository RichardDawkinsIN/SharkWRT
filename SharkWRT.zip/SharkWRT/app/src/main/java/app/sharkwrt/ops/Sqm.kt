package app.sharkwrt.ops

/**
 * SQM (Smart Queue Management) — keeps latency low under load by shaping the WAN just under
 * the line's real speed. Needs `sqm-scripts` and the cake qdisc (`kmod-sched-cake`). No Android
 * types here, so it is testable on the JVM.
 */
object Sqm {
    const val SECTION = "sharkwrt"
    val PACKAGES = listOf("sqm-scripts", "kmod-sched-cake")
    val SCRIPTS = listOf("piece_of_cake.qos", "layer_cake.qos", "simple.qos")

    /** Prints PKG/CAKE/PM markers, the sqm uci config, and what tc shows on the shaped device. */
    val STATUS: String =
        "echo \"PKG \$([ -x /etc/init.d/sqm ] && echo 1 || echo 0)\"; " +
            "echo \"CAKE \$( (lsmod 2>/dev/null | grep -q sch_cake || ls /lib/modules/*/sch_cake.ko >/dev/null 2>&1) && echo 1 || echo 0)\"; " +
            "echo \"PM \$(command -v apk >/dev/null 2>&1 && echo apk || echo opkg)\"; " +
            "echo UCI; uci -q show sqm 2>/dev/null; echo TC; " +
            "I=\$(uci -q show sqm 2>/dev/null | awk -F\"'\" '/\\.interface=/{print \$2; exit}'); " +
            "[ -n \"\$I\" ] && tc qdisc show dev \"\$I\" 2>/dev/null | head -n 3; echo END"

    val INSTALL: String =
        "if command -v apk >/dev/null 2>&1; then apk update >/dev/null 2>&1; apk add ${PACKAGES.joinToString(" ")} 2>&1; " +
            "else opkg update >/dev/null 2>&1; opkg install ${PACKAGES.joinToString(" ")} 2>&1; fi; " +
            "[ -x /etc/init.d/sqm ] && echo SQM_OK || echo SQM_FAILED"

    data class Config(
        val section: String,
        val enabled: Boolean,
        val iface: String,
        val downKbit: Int,
        val upKbit: Int,
        val script: String,
    )

    data class Status(
        val installed: Boolean,
        val cakeAvailable: Boolean,
        val packageManager: String,
        val config: Config?,
        /** What `tc qdisc show` printed for the shaped device. */
        val tc: String,
    ) {
        /** The cake/fq_codel shaper is really on the device right now. */
        val active: Boolean get() = tc.contains("cake") || tc.contains("fq_codel")
    }

    fun parse(stdout: String): Status {
        val lines = stdout.lines().map { it.trim() }
        fun marker(name: String) = lines.firstOrNull { it.startsWith("$name ") }?.substringAfter(' ')?.trim()
        val uciAt = lines.indexOf("UCI")
        val tcAt = lines.indexOf("TC")
        val endAt = lines.indexOf("END").let { if (it < 0) lines.size else it }
        val uci = if (uciAt >= 0 && tcAt > uciAt) Parsers.uciShow(lines.subList(uciAt + 1, tcAt).joinToString("\n")) else emptyMap()
        val tc = if (tcAt >= 0) lines.subList(tcAt + 1, maxOf(tcAt + 1, endAt)).joinToString("\n") else ""
        return Status(
            installed = marker("PKG") == "1",
            cakeAvailable = marker("CAKE") == "1",
            packageManager = marker("PM") ?: "opkg",
            config = config(uci),
            tc = tc,
        )
    }

    private fun config(uci: Map<String, String>): Config? {
        val section = uci.entries.firstOrNull { it.key.count { c -> c == '.' } == 1 && it.value == "queue" }
            ?.key?.substringAfter("sqm.") ?: return null
        fun f(k: String) = uci["sqm.$section.$k"]
        return Config(
            section = section,
            enabled = f("enabled") == "1",
            iface = f("interface").orEmpty(),
            downKbit = f("download")?.toIntOrNull() ?: 0,
            upKbit = f("upload")?.toIntOrNull() ?: 0,
            script = f("script") ?: "piece_of_cake.qos",
        )
    }

    /** Mbit/s as typed by a person → kbit/s for sqm. */
    fun mbitToKbit(mbit: String): Int? =
        mbit.trim().toDoubleOrNull()?.takeIf { it >= 0.0 && it <= 100_000.0 }?.let { (it * 1000).toInt() }

    fun valid(dev: String): Boolean = NetUsage.safeDevice(dev)

    fun applyOps(section: String, cfg: Config): List<String> = listOf(
        "set sqm.$section=queue",
        "set sqm.$section.interface='${cfg.iface}'",
        "set sqm.$section.enabled='${if (cfg.enabled) "1" else "0"}'",
        "set sqm.$section.download='${cfg.downKbit}'",
        "set sqm.$section.upload='${cfg.upKbit}'",
        "set sqm.$section.qdisc='cake'",
        "set sqm.$section.script='${cfg.script}'",
        "set sqm.$section.qdisc_advanced='0'",
        "set sqm.$section.linklayer='none'",
        "set sqm.$section.debug_logging='0'",
        "set sqm.$section.verbosity='5'",
    )

    fun reload(enabled: Boolean): String =
        if (enabled) "/etc/init.d/sqm enable && /etc/init.d/sqm restart"
        else "/etc/init.d/sqm stop; /etc/init.d/sqm disable; true"
}
