package app.sharkwrt.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * The names the user gave devices, by MAC, kept on this phone. Compose state, so a rename shows
 * everywhere at once — also in the demo, where there is no router to merge it in.
 */
object DeviceNames {
    var map: Map<String, String> by mutableStateOf(emptyMap())
}

/** What to show for a client: the user's own name if there is one, else what the router reports. */
val Client.label: String get() = DeviceNames.map[mac] ?: name
