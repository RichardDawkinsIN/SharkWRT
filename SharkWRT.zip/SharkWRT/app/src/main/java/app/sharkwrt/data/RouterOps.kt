package app.sharkwrt.data

import app.sharkwrt.net.RouterSession
import app.sharkwrt.net.SshException
import app.sharkwrt.ops.Commands
import app.sharkwrt.ops.NetCounters
import app.sharkwrt.ops.NetUsage
import app.sharkwrt.ops.Ookla
import app.sharkwrt.ops.Parsers

/** Outcome of a WAN speed test. Upload can fail on its own without losing the download. */
data class SpeedResult(
    val downMbps: Float = 0f,
    val downBytes: Long = 0,
    val downSeconds: Double = 0.0,
    val upMbps: Float = 0f,
    val upBytes: Long = 0,
    val upSeconds: Double = 0.0,
    val error: String? = null,
    val uploadError: String? = null,
    /** How busy the router's CPU was during each leg, 0–100; null when it could not be sampled. */
    val downCpuPct: Int? = null,
    val upCpuPct: Int? = null,
) {
    val hasUpload: Boolean get() = upBytes > 0 && upMbps > 0f

    /**
     * The router, not the line, set the number. A core with no idle left during the transfer
     * could not have moved bytes any faster whatever the link offered.
     */
    val cpuLimited: Boolean get() = cpuPct >= CPU_LIMITED_PCT

    /** The busier of the two legs, for the dialog's note. */
    val cpuPct: Int get() = maxOf(downCpuPct ?: 0, upCpuPct ?: 0)

    companion object {
        const val CPU_LIMITED_PCT = 90
    }
}

/** One leg as the router reported it: bytes moved, seconds it took, how busy the CPU was. */
data class Transfer(val bytes: Long, val seconds: Double, val cpuPct: Int? = null)

/** Which leg is running, for the dialog's progress line. */
enum class SpeedPhase { Download, Upload }

/** Where the Ookla client stands on this router, for the speed-test dialog. */
sealed class OoklaState {
    /** Asking the router. */
    data object Checking : OoklaState()
    data class Ready(val path: String) : OoklaState()
    /** Not there, but Ookla publishes a build for this CPU: [build] names it. */
    data class NeedsInstall(val build: String) : OoklaState()
    /** Ookla has no build for this CPU (MIPS routers, mostly). */
    data class Unsupported(val machine: String) : OoklaState()
    data class Failed(val message: String) : OoklaState()
}

/** The outcome of one Ookla run. */
sealed class OoklaOutcome {
    data class Done(val result: Ookla.Result) : OoklaOutcome()
    data class Error(val message: String) : OoklaOutcome()
}

/** Usage history on the router: absent, or a summary read from vnstat. */
sealed class UsageState {
    data object Loading : UsageState()
    /** The tracker is not set up on this router. */
    data object NotInstalled : UsageState()
    data object NoVnstat : UsageState()
    data class Ready(val summary: NetUsage.Summary) : UsageState()
    data class Failed(val message: String) : UsageState()
}

/** One-shot router actions from the dashboard's quick-action row. */
class RouterOps(private val session: RouterSession, private val telemetry: Telemetry? = null) {

    suspend fun reboot(): String = try {
        session.exec(Commands.REBOOT, timeoutMs = 10_000)
        "Reboot sent — the router goes down in a moment"
    } catch (e: SshException) {
        // The link can die before the reply lands; the command still reached the router.
        if (e is SshException.Disconnected || e is SshException.Timeout) "Reboot sent"
        else "Failed: ${e.message}"
    }

    /** Reads the tracker's daily and monthly figures; they are the router's, so they survive reboots. */
    suspend fun usageHistory(): UsageState = try {
        when (val read = NetUsage.parse(session.exec(NetUsage.READ, timeoutMs = 20_000).stdout)) {
            NetUsage.Read.NotInstalled -> UsageState.NotInstalled
            NetUsage.Read.NoVnstat -> UsageState.NoVnstat
            is NetUsage.Read.Ok -> UsageState.Ready(read.summary)
            is NetUsage.Read.Bad -> UsageState.Failed(read.message)
        }
    } catch (e: SshException) {
        UsageState.Failed(e.message ?: "Could not reach the router")
    }

    suspend fun sqmStatus(): Result<app.sharkwrt.ops.Sqm.Status> = try {
        Result.success(app.sharkwrt.ops.Sqm.parse(session.exec(app.sharkwrt.ops.Sqm.STATUS, timeoutMs = 15_000).stdout))
    } catch (e: SshException) {
        Result.failure(e)
    }

    /** Installs sqm-scripts and cake from the package feeds. Returns success and the output's tail. */
    suspend fun sqmInstall(): Pair<Boolean, String> = try {
        val r = session.exec(app.sharkwrt.ops.Sqm.INSTALL, timeoutMs = 300_000)
        val out = r.stdout + "\n" + r.stderr
        out.contains("SQM_OK") to NetUsage.tail(out)
    } catch (e: SshException) {
        false to (e.message ?: "Could not reach the router")
    }

    /** Writes the sqm queue section and starts or stops the shaper. Null on success, else the error. */
    suspend fun sqmApply(section: String, cfg: app.sharkwrt.ops.Sqm.Config): String? = try {
        session.exec(
            Commands.uciBatch(app.sharkwrt.ops.Sqm.applyOps(section, cfg), listOf("sqm"), app.sharkwrt.ops.Sqm.reload(cfg.enabled)),
            timeoutMs = 60_000,
        ).requireOk("sqm")
        null
    } catch (e: SshException) {
        e.message ?: "Could not apply"
    }

    /** Every netifd interface with a device: wan, wan6, lan, guest, … */
    suspend fun interfaces(): List<NetUsage.IfaceInfo> = try {
        NetUsage.parseIfaces(session.exec(NetUsage.IFACES, timeoutMs = 15_000).stdout)
    } catch (e: SshException) {
        emptyList()
    }

    /** Raw rx/tx byte counters of every netdev, for live rates in the interface view. */
    suspend fun netCounters(): Map<String, NetCounters> = try {
        Parsers.netCounters(session.exec("cat /proc/net/dev", timeoutMs = 10_000).stdout)
    } catch (e: SshException) {
        emptyMap()
    }

    /** vnstat history for one device (started if vnstat was not yet counting it). */
    suspend fun usageFor(dev: String): UsageState {
        if (!NetUsage.safeDevice(dev)) return UsageState.Failed("Odd interface name.")
        return try {
            when (val read = NetUsage.parse(session.exec(NetUsage.readFor(dev), timeoutMs = 25_000).stdout)) {
                NetUsage.Read.NotInstalled -> UsageState.NotInstalled
                NetUsage.Read.NoVnstat -> UsageState.NoVnstat
                is NetUsage.Read.Ok -> UsageState.Ready(read.summary)
                is NetUsage.Read.Bad -> UsageState.Failed(read.message)
            }
        } catch (e: SshException) {
            UsageState.Failed(e.message ?: "Could not reach the router")
        }
    }

    /**
     * Sends the bundled NetUsage installer to the router's shell. It installs vnstat (and nlbwmon),
     * moves vnstat's database onto flash so it survives reboots, and sets the tracker up. Needs
     * internet and the package feeds. Returns whether it finished, and the end of its output.
     */
    suspend fun installUsageTracker(script: ByteArray): Pair<Boolean, String> = try {
        val r = session.execWithInput(NetUsage.INSTALL, script, timeoutMs = 600_000)
        val out = r.stdout + "\n" + r.stderr
        NetUsage.installSucceeded(out) to NetUsage.tail(out)
    } catch (e: SshException) {
        false to (e.message ?: "Could not reach the router")
    }

    /** Is Ookla's client on the router, and if not, can it be put there. */
    suspend fun ooklaStatus(): OoklaState = try {
        val r = session.exec(Ookla.FIND, timeoutMs = 20_000)
        when (val found = Ookla.parseFind(r.stdout)) {
            is Ookla.Found.Installed -> OoklaState.Ready(found.path)
            is Ookla.Found.Missing -> OoklaState.NeedsInstall(found.build)
            is Ookla.Found.Unsupported -> OoklaState.Unsupported(found.machine)
        }
    } catch (e: SshException) {
        OoklaState.Failed(e.message ?: "Could not reach the router")
    }

    /** Fetches Ookla's client into the router's RAM disk. Needs the router to be online. */
    suspend fun ooklaInstall(build: String): OoklaState = try {
        val r = session.exec(Ookla.install(build), timeoutMs = 180_000)
        if (r.ok && Ookla.looksInstalled(r.stdout)) {
            OoklaState.Ready("${Ookla.DIR}/speedtest")
        } else {
            OoklaState.Failed(
                "The download did not work. The router needs internet and a fetcher with HTTPS " +
                    "(curl, or uclient-fetch with ca-bundle).",
            )
        }
    } catch (e: SshException) {
        OoklaState.Failed(e.message ?: "Could not reach the router")
    }

    /**
     * Runs the Ookla test on the router: ping, then download, then upload against a server the
     * client picks. The dashboard tick is held meanwhile, as for the quick test.
     */
    suspend fun ooklaRun(path: String): OoklaOutcome {
        val command = Ookla.run(path) ?: return OoklaOutcome.Error("Unexpected client path.")
        telemetry?.paused = true
        return try {
            val r = session.exec(command, timeoutMs = 240_000)
            when (val parsed = Ookla.parseResult(r.stdout)) {
                is Ookla.Parsed.Ok -> OoklaOutcome.Done(parsed.result)
                is Ookla.Parsed.Failed -> OoklaOutcome.Error(parsed.message)
            }
        } catch (e: SshException) {
            OoklaOutcome.Error(e.message ?: "Could not reach the router")
        } finally {
            telemetry?.paused = false
        }
    }

    /**
     * Measures WAN throughput with one download and then one upload run on the router, each
     * up to 100 MB or [Commands.SPEEDTEST_SECONDS], whichever ends first, dividing what moved
     * by how long it took. It is the router's number as much as the line's: a single small
     * core pushing bytes through curl can be the ceiling, so each leg also samples how busy
     * the CPU was. The dashboard tick is held for the duration — it would otherwise share
     * that same core.
     */
    suspend fun speedtest(onPhase: (SpeedPhase) -> Unit = {}): SpeedResult {
        telemetry?.paused = true
        try {
            onPhase(SpeedPhase.Download)
            val down = timedTransfer(Commands.speedtestDownload())
                ?: return SpeedResult(error = "Download failed — is the router online?")

            onPhase(SpeedPhase.Upload)
            val up = try {
                session.exec(Commands.speedtestPrepareUpload(), timeoutMs = 60_000)
                    .takeIf { it.ok }
                    ?.let { timedTransfer(Commands.speedtestUpload()) }
            } catch (e: SshException) {
                null
            } finally {
                runCatching { session.exec(Commands.SPEEDTEST_CLEANUP, timeoutMs = 15_000) }
            }

            return SpeedResult(
                downMbps = Telemetry.mbps(down.bytes, down.seconds),
                downBytes = down.bytes,
                downSeconds = down.seconds,
                downCpuPct = down.cpuPct,
                upMbps = up?.let { Telemetry.mbps(it.bytes, it.seconds) } ?: 0f,
                upBytes = up?.bytes ?: 0,
                upSeconds = up?.seconds ?: 0.0,
                upCpuPct = up?.cpuPct,
                uploadError = if (up == null) "Upload failed — is the router online?" else null,
            )
        } finally {
            telemetry?.paused = false
        }
    }

    /**
     * Runs one leg and returns the bytes it confirmed plus how long they took to move.
     *
     * With curl the router reports its own numbers — bytes down, bytes up, total time, and
     * the time before the first byte moved — and the transfer time is the difference of the
     * last two, so DNS and connection setup are left out; a leg the clock cut short reports
     * what had arrived by then. Without curl the router runs the same clock itself and
     * reports bytes and seconds of its own, so the SSH round trip does not pad the time.
     */
    private suspend fun timedTransfer(command: String): Transfer? = try {
        val started = System.nanoTime()
        val result = session.exec(command, timeoutMs = 180_000)
        val wall = (System.nanoTime() - started) / 1e9
        val parsed = parseTransfer(result.stdout, wall)
        if (!result.ok || parsed == null || parsed.seconds <= 0.05) null else parsed
    } catch (e: SshException) {
        null
    }

    companion object {
        /**
         * A transfer command's output → what moved, how long it took, how busy the CPU was.
         *
         * The transfer line is the last one that is not a /proc/stat sample: four fields are
         * curl's `size_download size_upload time_total time_pretransfer`, whichever size is
         * non-zero being the leg that ran; two are the no-curl fallback's own count and clock,
         * the bytes moved and the seconds they took as read on the router; one is a bare byte
         * count, timed by [wall]. The `cpu` lines either side of it give the core's share of
         * that time. Anything else is a failed transfer.
         */
        fun parseTransfer(stdout: String, wall: Double): Transfer? {
            val lines = stdout.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val samples = lines.mapNotNull(Parsers::cpuSample)
            val cpuPct = if (samples.size >= 2) samples.last().percentSince(samples.first()) else null
            val fields = lines.lastOrNull { !it.startsWith("cpu ") }?.split(Regex("\\s+")).orEmpty()
            val (bytes, seconds) = when (fields.size) {
                1 -> (fields[0].toLongOrNull() ?: return null) to wall
                2 -> (fields[0].toLongOrNull() ?: return null) to (fields[1].toDoubleOrNull() ?: return null)
                4 -> {
                    val down = fields[0].toLongOrNull() ?: return null
                    val up = fields[1].toLongOrNull() ?: return null
                    val total = fields[2].toDoubleOrNull() ?: return null
                    val pre = fields[3].toDoubleOrNull() ?: return null
                    (if (up > 0) up else down) to ((total - pre).takeIf { it > 0 } ?: wall)
                }
                else -> return null
            }
            return if (bytes <= 0) null else Transfer(bytes, seconds, cpuPct)
        }
    }

}
