package app.sharkwrt.ops

import org.json.JSONException
import org.json.JSONObject

/**
 * Ookla's own Speedtest command-line client, run on the router.
 *
 * It is a closed-source binary Ookla publishes for a few CPU families; OpenWrt has no package
 * for it. The app can fetch it from Ookla's install server into /tmp (RAM, gone on reboot, so
 * no flash is used) and run it with `-f json`. No Android types in here, so the parsing is
 * testable on the JVM.
 */
object Ookla {
    const val VERSION = "1.2.0"
    const val DIR = "/tmp/sharkwrt-ookla"

    /** Where a copy the router already has might be, then the one the app downloads. */
    private val KNOWN_PATHS = listOf(
        "/usr/bin/ookla-speedtest",   // where the NetUsage tracker installs it
        "/usr/bin/speedtest",
        "/usr/sbin/speedtest",
        "/usr/local/bin/speedtest",
        "$DIR/speedtest",
    )

    /**
     * Prints the path of an Ookla client if the router has one (other programs are called
     * `speedtest` too, so the version banner has to say Ookla), otherwise `none` and the CPU
     * architecture, which is what decides whether a build exists for this router.
     */
    val FIND: String =
        "for p in ${KNOWN_PATHS.joinToString(" ")}; do " +
            "if [ -x \"\$p\" ] && \"\$p\" --version 2>/dev/null | grep -qi ookla; then echo \"\$p\"; exit 0; fi; " +
            "done; echo none; uname -m"

    /** The result of [FIND]. */
    sealed class Found {
        data class Installed(val path: String) : Found()
        data class Missing(val build: String) : Found()
        data class Unsupported(val machine: String) : Found()
    }

    fun parseFind(stdout: String): Found {
        val lines = stdout.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val first = lines.firstOrNull() ?: return Found.Unsupported("unknown")
        if (first != "none") {
            return if (isSafePath(first)) Found.Installed(first) else Found.Unsupported("unknown")
        }
        val machine = lines.getOrNull(1).orEmpty()
        val build = buildFor(machine) ?: return Found.Unsupported(machine.ifBlank { "unknown" })
        return Found.Missing(build)
    }

    /** Ookla's download name for a `uname -m`, or null where it publishes nothing (MIPS, for one). */
    fun buildFor(machine: String): String? = when (machine.lowercase()) {
        "aarch64", "arm64" -> "aarch64"
        "armv7l", "armv7", "armv8l" -> "armhf"
        "armv6l", "armv5tel", "armv5tejl" -> "armel"
        "x86_64", "amd64" -> "x86_64"
        "i686", "i586", "i386" -> "i386"
        else -> null
    }

    fun downloadUrl(build: String): String =
        "https://install.speedtest.net/app/cli/ookla-speedtest-$VERSION-linux-$build.tgz"

    /**
     * Downloads the archive with whichever fetcher the router has, unpacks only the binary, and
     * prints its version banner. gzip into tar rather than `tar -z`, which not every busybox has.
     */
    fun install(build: String): String =
        "mkdir -p $DIR && cd $DIR && rm -f o.tgz speedtest && " +
            "( curl -fsSL -o o.tgz '${downloadUrl(build)}' || " +
            "uclient-fetch -q -O o.tgz '${downloadUrl(build)}' || " +
            "wget -q -O o.tgz '${downloadUrl(build)}' ) && " +
            "gzip -dc o.tgz | tar -xf - speedtest && rm -f o.tgz && chmod +x speedtest && ./speedtest --version"

    /** The banner of a client that really is Ookla's. */
    fun looksInstalled(versionOutput: String): Boolean = versionOutput.contains("ookla", ignoreCase = true)

    /** Accepting the licence is a flag, not a prompt; the dialog tells the user they are doing so. */
    fun run(path: String): String? =
        if (isSafePath(path)) "$path --accept-license --accept-gdpr -f json -p no 2>&1" else null

    fun remove(): String = "rm -rf $DIR"

    private fun isSafePath(path: String): Boolean = path.matches(Regex("^/[A-Za-z0-9/_.-]+$"))

    // ── The result ────────────────────────────────────────────────────────────

    data class Result(
        val downMbps: Float,
        val upMbps: Float,
        val pingMs: Float,
        val jitterMs: Float?,
        val downBytes: Long,
        val upBytes: Long,
        val packetLossPct: Float?,
        val server: String,
        val isp: String?,
        val externalIp: String?,
        val resultUrl: String?,
    )

    sealed class Parsed {
        data class Ok(val result: Result) : Parsed()
        data class Failed(val message: String) : Parsed()
    }

    /**
     * The client prints one JSON object per line: `log` lines as it goes and a `result` line at
     * the end. Bandwidth is bytes per second.
     */
    fun parseResult(stdout: String): Parsed {
        var failure: String? = null
        for (line in stdout.lines().asReversed()) {
            val text = line.trim()
            if (!text.startsWith("{")) continue
            val obj = try {
                JSONObject(text)
            } catch (e: JSONException) {
                continue
            }
            when (obj.optString("type")) {
                "result" -> return Parsed.Ok(toResult(obj))
                "log" -> if (failure == null && obj.optString("level") == "error") {
                    failure = obj.optString("message").ifBlank { null }
                }
            }
        }
        return Parsed.Failed(failure ?: "The Ookla client gave no result.")
    }

    private fun toResult(obj: JSONObject): Result {
        val down = obj.optJSONObject("download")
        val up = obj.optJSONObject("upload")
        val ping = obj.optJSONObject("ping")
        val server = obj.optJSONObject("server")
        val name = server?.optString("name").orEmpty()
        val place = listOf(server?.optString("location").orEmpty(), server?.optString("country").orEmpty())
            .filter { it.isNotBlank() }.joinToString(", ")
        return Result(
            downMbps = mbps(down?.optDouble("bandwidth", 0.0) ?: 0.0),
            upMbps = mbps(up?.optDouble("bandwidth", 0.0) ?: 0.0),
            pingMs = (ping?.optDouble("latency", 0.0) ?: 0.0).toFloat(),
            jitterMs = ping?.takeIf { it.has("jitter") }?.optDouble("jitter")?.toFloat(),
            downBytes = down?.optLong("bytes", 0L) ?: 0L,
            upBytes = up?.optLong("bytes", 0L) ?: 0L,
            packetLossPct = if (obj.has("packetLoss")) obj.optDouble("packetLoss").toFloat() else null,
            server = listOf(name, place).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "unknown server" },
            isp = obj.optString("isp").ifBlank { null },
            externalIp = obj.optJSONObject("interface")?.optString("externalIp")?.ifBlank { null },
            resultUrl = obj.optJSONObject("result")?.optString("url")?.ifBlank { null },
        )
    }

    /** Bytes per second → megabits per second. */
    private fun mbps(bytesPerSecond: Double): Float = (bytesPerSecond * 8.0 / 1_000_000.0).toFloat()
}
