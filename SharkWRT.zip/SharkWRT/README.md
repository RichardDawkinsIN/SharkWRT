# SharkWRT

OpenWrt control from your phone over SSH — sci-fi liquid-glass UI. Android, Kotlin, Jetpack Compose.

Build: push to GitHub; `.github/workflows/build.yml` compiles the debug APK (it also unzips a project ZIP placed in the repo root, if any).

Based on the MIT-licensed WrtPulse by Vivek Kumar (see LICENSE.md).
